package date1;

import java.util.Date;

public class DateDemo2 {

	public static void main(String[] args) {
		
//		Date date = new Date(0);
//		System.out.println(date);
		
		Date date = new Date(-1929292929292L);
		System.out.println(date);
		
		
		Date date0 = new Date(1000000000000L);
		System.out.println(date0);
		Date date1 = new Date(1100000000000L);
		System.out.println(date1);
		Date date2 = new Date(1200000000000L);
		System.out.println(date2);
		Date date3 = new Date(1300000000000L);
		System.out.println(date3);
		Date date4 = new Date(1400000000000L);
		System.out.println(date4);
		Date date5 = new Date(1500000000000L);
		System.out.println(date5);
				
		Date date6 = new Date(10000000000000L);
		System.out.println(date6);
		
	}
}
